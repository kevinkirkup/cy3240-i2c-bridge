//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules

struct I2C_Regs {    // Example I2C interface structure  
    WORD wX1;  //read/write value
    int iADC;  // read only Value
    BYTE bStatus; //	read only Value
} MyI2C_Regs;  
  
void main()  
{  
WORD wLop;
INT iA;
   EzI2Cs_SetRamBuffer(5, 2, (BYTE *) &MyI2C_Regs);  // Set up RAM buffer  
   M8C_EnableGInt;                        	         // Turn on interrupts  
   EzI2Cs_Start();                                   // Turn on I2C  
//............
// wX1 access
   M8C_DisableGInt; //!!! turn off interrupt if variable holds more than 1 byte!                                                                                                                           
   wLop=MyI2C_Regs.wX1;	
   M8C_EnableGInt;  // turn on interrupt
//...........
//............
// iADC access
   M8C_DisableGInt; //!!! turn off interrupt if variable holds more than 1 byte!                                                                                                                           
   MyI2C_Regs.iADC=iA;	
   M8C_EnableGInt;  // turn on interrupt
//...........
//...........
// bStatus access is not need interrupt disable
   MyI2C_Regs.bStatus=0x20;
//...........
}  


