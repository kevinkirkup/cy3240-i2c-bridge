//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules

extern BYTE  EzI2Cs_bRAM_RWcntr;
extern WORD  TRIADC8_iResult1;
extern WORD  TRIADC8_iResult2;
extern WORD  TRIADC8_iResult3;
extern BYTE  TRIADC8_bfStatus;
#define TRIADC8_fDATA_READY  0x10
BYTE cResult[6];
WORD wFixCount;
WORD wCount;
BYTE	Gain1,Gain2,Gain3;

#pragma interrupt_handler Sleep_Timer_handler;

void Sleep_Timer_handler(void)
{
wFixCount=wCount;
wCount=0;
PRT1DR^=0x08;
}


void main()  
{  
long Temp;

   EzI2Cs_SetRamBuffer(6, 3, (BYTE *) &cResult);  // Set up RAM buffer  
   M8C_EnableIntMask(INT_MSK0, 0x40); 	
   M8C_EnableGInt;                        	         // Turn on interrupts  
   EzI2Cs_Start();                                   // Turn on I2C  
   PGA_1_Start(3);
   PGA_2_Start(3);
   PGA_3_Start(3);      
  TRIADC8_Start(TRIADC8_HIGHPOWER); // Turn on Analog section   
  TRIADC8_GetSamples();             // Start ADC to read continuously    
  
  cResult[0]=0xF8;cResult[1]=0xF8;cResult[2]=0xF8;

  
  
  for(;;)    
  {    
    while(TRIADC8_fIsDataAvailable() == 0);   // Wait for data to be ready    
    cResult[3] = TRIADC8_iResult1;
    cResult[4] = TRIADC8_iResult2;
    cResult[5] = TRIADC8_iResult3;
    TRIADC8_bfStatus&=~TRIADC8_fDATA_READY;
//    cResult[0] = TRIADC8_cGetData1();           // Get Data from ADC Input1    
//    cResult[1] = TRIADC8_cGetData2();           // Get Data from ADC Input2    
//    cResult[2] = TRIADC8_cGetData3ClearFlag();  // Get Data from ADC Input3    
    wCount++;
    if (cResult[0]!=Gain1) 
    					{
    					Gain1=cResult[0];
    					PGA_1_SetGain(Gain1);
    					}
    if (cResult[1]!=Gain2) 
    					{
    					Gain2=cResult[1];
    					PGA_2_SetGain(Gain2);
    					}
    if (cResult[2]!=Gain3) 
    					{
    					Gain3=cResult[2];
    					PGA_3_SetGain(Gain3);
    					}
    					
	}
}




