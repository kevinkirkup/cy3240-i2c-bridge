//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules

extern BYTE  EzI2Cs_bRAM_RWcntr;

long Freq;  //read/write value
WORD wPlus; //counter (clk)of PWM positive signal durance
WORD wMinus;//counter (clk)of PWM negative signal durance
WORD wRun;//used by timer interrupt,hold last comparator value
WORD wDuty; //duty factor 0..255
BYTE fgUpdate;

void main()  
{  
long Temp;

   EzI2Cs_SetRamBuffer(4, 0, (BYTE *) &Freq);  // Set up RAM buffer  
   M8C_EnableGInt;                        	         // Turn on interrupts  
   EzI2Cs_Start();                                   // Turn on I2C  
	Timer16_Start();
	Timer16_EnableInt(); 
while(1)
{
if (fgUpdate)
	{
	fgUpdate=0;
	M8C_DisableGInt;
	Temp=(wMinus+wPlus);
	M8C_EnableGInt;
	
	Temp=1000000/Temp;

	if ((EzI2Cs_bRAM_RWcntr==0)||(EzI2Cs_bRAM_RWcntr>3))
	{
	M8C_DisableGInt;
	Freq=Temp;
	M8C_EnableGInt;
	}
	}
}

}  


