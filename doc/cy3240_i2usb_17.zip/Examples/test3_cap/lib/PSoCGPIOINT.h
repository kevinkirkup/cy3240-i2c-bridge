// CSR_1SW7 address and mask defines
#pragma	ioport	CSR_1SW7_Data_ADDR:	0x0
BYTE			CSR_1SW7_Data_ADDR;
#pragma	ioport	CSR_1SW7_DriveMode_0_ADDR:	0x100
BYTE			CSR_1SW7_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW7_DriveMode_1_ADDR:	0x101
BYTE			CSR_1SW7_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW7_DriveMode_2_ADDR:	0x3
BYTE			CSR_1SW7_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW7_GlobalSelect_ADDR:	0x2
BYTE			CSR_1SW7_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW7_IntCtrl_0_ADDR:	0x102
BYTE			CSR_1SW7_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW7_IntCtrl_1_ADDR:	0x103
BYTE			CSR_1SW7_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW7_IntEn_ADDR:	0x1
BYTE			CSR_1SW7_IntEn_ADDR;
#define CSR_1SW7_MASK 0x1
#pragma	ioport	CSR_1SW7_MUXBusCtrl_ADDR:	0x1d8
BYTE			CSR_1SW7_MUXBusCtrl_ADDR;
// CSR_1SW7 Shadow defines
//   CSR_1SW7_DataShadow define
extern BYTE Port_0_Data_SHADE;
#define CSR_1SW7_DataShadow (*(unsigned char*)&Port_0_Data_SHADE)
// CSR_1SW8 address and mask defines
#pragma	ioport	CSR_1SW8_Data_ADDR:	0x0
BYTE			CSR_1SW8_Data_ADDR;
#pragma	ioport	CSR_1SW8_DriveMode_0_ADDR:	0x100
BYTE			CSR_1SW8_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW8_DriveMode_1_ADDR:	0x101
BYTE			CSR_1SW8_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW8_DriveMode_2_ADDR:	0x3
BYTE			CSR_1SW8_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW8_GlobalSelect_ADDR:	0x2
BYTE			CSR_1SW8_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW8_IntCtrl_0_ADDR:	0x102
BYTE			CSR_1SW8_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW8_IntCtrl_1_ADDR:	0x103
BYTE			CSR_1SW8_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW8_IntEn_ADDR:	0x1
BYTE			CSR_1SW8_IntEn_ADDR;
#define CSR_1SW8_MASK 0x2
#pragma	ioport	CSR_1SW8_MUXBusCtrl_ADDR:	0x1d8
BYTE			CSR_1SW8_MUXBusCtrl_ADDR;
// CSR_1SW8 Shadow defines
//   CSR_1SW8_DataShadow define
extern BYTE Port_0_Data_SHADE;
#define CSR_1SW8_DataShadow (*(unsigned char*)&Port_0_Data_SHADE)
// CSR_1SW9 address and mask defines
#pragma	ioport	CSR_1SW9_Data_ADDR:	0x0
BYTE			CSR_1SW9_Data_ADDR;
#pragma	ioport	CSR_1SW9_DriveMode_0_ADDR:	0x100
BYTE			CSR_1SW9_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW9_DriveMode_1_ADDR:	0x101
BYTE			CSR_1SW9_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW9_DriveMode_2_ADDR:	0x3
BYTE			CSR_1SW9_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW9_GlobalSelect_ADDR:	0x2
BYTE			CSR_1SW9_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW9_IntCtrl_0_ADDR:	0x102
BYTE			CSR_1SW9_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW9_IntCtrl_1_ADDR:	0x103
BYTE			CSR_1SW9_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW9_IntEn_ADDR:	0x1
BYTE			CSR_1SW9_IntEn_ADDR;
#define CSR_1SW9_MASK 0x4
#pragma	ioport	CSR_1SW9_MUXBusCtrl_ADDR:	0x1d8
BYTE			CSR_1SW9_MUXBusCtrl_ADDR;
// CSR_1SW9 Shadow defines
//   CSR_1SW9_DataShadow define
extern BYTE Port_0_Data_SHADE;
#define CSR_1SW9_DataShadow (*(unsigned char*)&Port_0_Data_SHADE)
// CSR_1SW11 address and mask defines
#pragma	ioport	CSR_1SW11_Data_ADDR:	0x0
BYTE			CSR_1SW11_Data_ADDR;
#pragma	ioport	CSR_1SW11_DriveMode_0_ADDR:	0x100
BYTE			CSR_1SW11_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW11_DriveMode_1_ADDR:	0x101
BYTE			CSR_1SW11_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW11_DriveMode_2_ADDR:	0x3
BYTE			CSR_1SW11_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW11_GlobalSelect_ADDR:	0x2
BYTE			CSR_1SW11_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW11_IntCtrl_0_ADDR:	0x102
BYTE			CSR_1SW11_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW11_IntCtrl_1_ADDR:	0x103
BYTE			CSR_1SW11_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW11_IntEn_ADDR:	0x1
BYTE			CSR_1SW11_IntEn_ADDR;
#define CSR_1SW11_MASK 0x10
#pragma	ioport	CSR_1SW11_MUXBusCtrl_ADDR:	0x1d8
BYTE			CSR_1SW11_MUXBusCtrl_ADDR;
// CSR_1SW11 Shadow defines
//   CSR_1SW11_DataShadow define
extern BYTE Port_0_Data_SHADE;
#define CSR_1SW11_DataShadow (*(unsigned char*)&Port_0_Data_SHADE)
// CSR_1SW12 address and mask defines
#pragma	ioport	CSR_1SW12_Data_ADDR:	0x0
BYTE			CSR_1SW12_Data_ADDR;
#pragma	ioport	CSR_1SW12_DriveMode_0_ADDR:	0x100
BYTE			CSR_1SW12_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW12_DriveMode_1_ADDR:	0x101
BYTE			CSR_1SW12_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW12_DriveMode_2_ADDR:	0x3
BYTE			CSR_1SW12_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW12_GlobalSelect_ADDR:	0x2
BYTE			CSR_1SW12_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW12_IntCtrl_0_ADDR:	0x102
BYTE			CSR_1SW12_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW12_IntCtrl_1_ADDR:	0x103
BYTE			CSR_1SW12_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW12_IntEn_ADDR:	0x1
BYTE			CSR_1SW12_IntEn_ADDR;
#define CSR_1SW12_MASK 0x20
#pragma	ioport	CSR_1SW12_MUXBusCtrl_ADDR:	0x1d8
BYTE			CSR_1SW12_MUXBusCtrl_ADDR;
// CSR_1SW12 Shadow defines
//   CSR_1SW12_DataShadow define
extern BYTE Port_0_Data_SHADE;
#define CSR_1SW12_DataShadow (*(unsigned char*)&Port_0_Data_SHADE)
// CSR_1SW13 address and mask defines
#pragma	ioport	CSR_1SW13_Data_ADDR:	0x0
BYTE			CSR_1SW13_Data_ADDR;
#pragma	ioport	CSR_1SW13_DriveMode_0_ADDR:	0x100
BYTE			CSR_1SW13_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW13_DriveMode_1_ADDR:	0x101
BYTE			CSR_1SW13_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW13_DriveMode_2_ADDR:	0x3
BYTE			CSR_1SW13_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW13_GlobalSelect_ADDR:	0x2
BYTE			CSR_1SW13_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW13_IntCtrl_0_ADDR:	0x102
BYTE			CSR_1SW13_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW13_IntCtrl_1_ADDR:	0x103
BYTE			CSR_1SW13_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW13_IntEn_ADDR:	0x1
BYTE			CSR_1SW13_IntEn_ADDR;
#define CSR_1SW13_MASK 0x40
#pragma	ioport	CSR_1SW13_MUXBusCtrl_ADDR:	0x1d8
BYTE			CSR_1SW13_MUXBusCtrl_ADDR;
// CSR_1SW13 Shadow defines
//   CSR_1SW13_DataShadow define
extern BYTE Port_0_Data_SHADE;
#define CSR_1SW13_DataShadow (*(unsigned char*)&Port_0_Data_SHADE)
// CSR_1SW14 address and mask defines
#pragma	ioport	CSR_1SW14_Data_ADDR:	0x0
BYTE			CSR_1SW14_Data_ADDR;
#pragma	ioport	CSR_1SW14_DriveMode_0_ADDR:	0x100
BYTE			CSR_1SW14_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW14_DriveMode_1_ADDR:	0x101
BYTE			CSR_1SW14_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW14_DriveMode_2_ADDR:	0x3
BYTE			CSR_1SW14_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW14_GlobalSelect_ADDR:	0x2
BYTE			CSR_1SW14_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW14_IntCtrl_0_ADDR:	0x102
BYTE			CSR_1SW14_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW14_IntCtrl_1_ADDR:	0x103
BYTE			CSR_1SW14_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW14_IntEn_ADDR:	0x1
BYTE			CSR_1SW14_IntEn_ADDR;
#define CSR_1SW14_MASK 0x80
#pragma	ioport	CSR_1SW14_MUXBusCtrl_ADDR:	0x1d8
BYTE			CSR_1SW14_MUXBusCtrl_ADDR;
// CSR_1SW14 Shadow defines
//   CSR_1SW14_DataShadow define
extern BYTE Port_0_Data_SHADE;
#define CSR_1SW14_DataShadow (*(unsigned char*)&Port_0_Data_SHADE)
// EzI2CsSCL address and mask defines
#pragma	ioport	EzI2CsSCL_Data_ADDR:	0x4
BYTE			EzI2CsSCL_Data_ADDR;
#pragma	ioport	EzI2CsSCL_DriveMode_0_ADDR:	0x104
BYTE			EzI2CsSCL_DriveMode_0_ADDR;
#pragma	ioport	EzI2CsSCL_DriveMode_1_ADDR:	0x105
BYTE			EzI2CsSCL_DriveMode_1_ADDR;
#pragma	ioport	EzI2CsSCL_DriveMode_2_ADDR:	0x7
BYTE			EzI2CsSCL_DriveMode_2_ADDR;
#pragma	ioport	EzI2CsSCL_GlobalSelect_ADDR:	0x6
BYTE			EzI2CsSCL_GlobalSelect_ADDR;
#pragma	ioport	EzI2CsSCL_IntCtrl_0_ADDR:	0x106
BYTE			EzI2CsSCL_IntCtrl_0_ADDR;
#pragma	ioport	EzI2CsSCL_IntCtrl_1_ADDR:	0x107
BYTE			EzI2CsSCL_IntCtrl_1_ADDR;
#pragma	ioport	EzI2CsSCL_IntEn_ADDR:	0x5
BYTE			EzI2CsSCL_IntEn_ADDR;
#define EzI2CsSCL_MASK 0x2
#pragma	ioport	EzI2CsSCL_MUXBusCtrl_ADDR:	0x1d9
BYTE			EzI2CsSCL_MUXBusCtrl_ADDR;
// EzI2CsSCL Shadow defines
//   EzI2CsSCL_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define EzI2CsSCL_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
// CSR_1SW6 address and mask defines
#pragma	ioport	CSR_1SW6_Data_ADDR:	0x4
BYTE			CSR_1SW6_Data_ADDR;
#pragma	ioport	CSR_1SW6_DriveMode_0_ADDR:	0x104
BYTE			CSR_1SW6_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW6_DriveMode_1_ADDR:	0x105
BYTE			CSR_1SW6_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW6_DriveMode_2_ADDR:	0x7
BYTE			CSR_1SW6_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW6_GlobalSelect_ADDR:	0x6
BYTE			CSR_1SW6_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW6_IntCtrl_0_ADDR:	0x106
BYTE			CSR_1SW6_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW6_IntCtrl_1_ADDR:	0x107
BYTE			CSR_1SW6_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW6_IntEn_ADDR:	0x5
BYTE			CSR_1SW6_IntEn_ADDR;
#define CSR_1SW6_MASK 0x8
#pragma	ioport	CSR_1SW6_MUXBusCtrl_ADDR:	0x1d9
BYTE			CSR_1SW6_MUXBusCtrl_ADDR;
// CSR_1SW6 Shadow defines
//   CSR_1SW6_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define CSR_1SW6_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
// CSR_1SW0 address and mask defines
#pragma	ioport	CSR_1SW0_Data_ADDR:	0x4
BYTE			CSR_1SW0_Data_ADDR;
#pragma	ioport	CSR_1SW0_DriveMode_0_ADDR:	0x104
BYTE			CSR_1SW0_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW0_DriveMode_1_ADDR:	0x105
BYTE			CSR_1SW0_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW0_DriveMode_2_ADDR:	0x7
BYTE			CSR_1SW0_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW0_GlobalSelect_ADDR:	0x6
BYTE			CSR_1SW0_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW0_IntCtrl_0_ADDR:	0x106
BYTE			CSR_1SW0_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW0_IntCtrl_1_ADDR:	0x107
BYTE			CSR_1SW0_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW0_IntEn_ADDR:	0x5
BYTE			CSR_1SW0_IntEn_ADDR;
#define CSR_1SW0_MASK 0x10
#pragma	ioport	CSR_1SW0_MUXBusCtrl_ADDR:	0x1d9
BYTE			CSR_1SW0_MUXBusCtrl_ADDR;
// CSR_1SW0 Shadow defines
//   CSR_1SW0_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define CSR_1SW0_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
// CSR_1SW1 address and mask defines
#pragma	ioport	CSR_1SW1_Data_ADDR:	0x4
BYTE			CSR_1SW1_Data_ADDR;
#pragma	ioport	CSR_1SW1_DriveMode_0_ADDR:	0x104
BYTE			CSR_1SW1_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW1_DriveMode_1_ADDR:	0x105
BYTE			CSR_1SW1_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW1_DriveMode_2_ADDR:	0x7
BYTE			CSR_1SW1_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW1_GlobalSelect_ADDR:	0x6
BYTE			CSR_1SW1_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW1_IntCtrl_0_ADDR:	0x106
BYTE			CSR_1SW1_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW1_IntCtrl_1_ADDR:	0x107
BYTE			CSR_1SW1_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW1_IntEn_ADDR:	0x5
BYTE			CSR_1SW1_IntEn_ADDR;
#define CSR_1SW1_MASK 0x40
#pragma	ioport	CSR_1SW1_MUXBusCtrl_ADDR:	0x1d9
BYTE			CSR_1SW1_MUXBusCtrl_ADDR;
// CSR_1SW1 Shadow defines
//   CSR_1SW1_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define CSR_1SW1_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
// CSR_1SW10 address and mask defines
#pragma	ioport	CSR_1SW10_Data_ADDR:	0x8
BYTE			CSR_1SW10_Data_ADDR;
#pragma	ioport	CSR_1SW10_DriveMode_0_ADDR:	0x108
BYTE			CSR_1SW10_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW10_DriveMode_1_ADDR:	0x109
BYTE			CSR_1SW10_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW10_DriveMode_2_ADDR:	0xb
BYTE			CSR_1SW10_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW10_GlobalSelect_ADDR:	0xa
BYTE			CSR_1SW10_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW10_IntCtrl_0_ADDR:	0x10a
BYTE			CSR_1SW10_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW10_IntCtrl_1_ADDR:	0x10b
BYTE			CSR_1SW10_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW10_IntEn_ADDR:	0x9
BYTE			CSR_1SW10_IntEn_ADDR;
#define CSR_1SW10_MASK 0x80
#pragma	ioport	CSR_1SW10_MUXBusCtrl_ADDR:	0x1da
BYTE			CSR_1SW10_MUXBusCtrl_ADDR;
// CSR_1SW10 Shadow defines
//   CSR_1SW10_DataShadow define
extern BYTE Port_2_Data_SHADE;
#define CSR_1SW10_DataShadow (*(unsigned char*)&Port_2_Data_SHADE)
// CSR_1SW2 address and mask defines
#pragma	ioport	CSR_1SW2_Data_ADDR:	0xc
BYTE			CSR_1SW2_Data_ADDR;
#pragma	ioport	CSR_1SW2_DriveMode_0_ADDR:	0x10c
BYTE			CSR_1SW2_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW2_DriveMode_1_ADDR:	0x10d
BYTE			CSR_1SW2_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW2_DriveMode_2_ADDR:	0xf
BYTE			CSR_1SW2_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW2_GlobalSelect_ADDR:	0xe
BYTE			CSR_1SW2_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW2_IntCtrl_0_ADDR:	0x10e
BYTE			CSR_1SW2_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW2_IntCtrl_1_ADDR:	0x10f
BYTE			CSR_1SW2_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW2_IntEn_ADDR:	0xd
BYTE			CSR_1SW2_IntEn_ADDR;
#define CSR_1SW2_MASK 0x1
#pragma	ioport	CSR_1SW2_MUXBusCtrl_ADDR:	0x1db
BYTE			CSR_1SW2_MUXBusCtrl_ADDR;
// CSR_1SW2 Shadow defines
//   CSR_1SW2_DataShadow define
extern BYTE Port_3_Data_SHADE;
#define CSR_1SW2_DataShadow (*(unsigned char*)&Port_3_Data_SHADE)
// CSR_1SW5 address and mask defines
#pragma	ioport	CSR_1SW5_Data_ADDR:	0xc
BYTE			CSR_1SW5_Data_ADDR;
#pragma	ioport	CSR_1SW5_DriveMode_0_ADDR:	0x10c
BYTE			CSR_1SW5_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW5_DriveMode_1_ADDR:	0x10d
BYTE			CSR_1SW5_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW5_DriveMode_2_ADDR:	0xf
BYTE			CSR_1SW5_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW5_GlobalSelect_ADDR:	0xe
BYTE			CSR_1SW5_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW5_IntCtrl_0_ADDR:	0x10e
BYTE			CSR_1SW5_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW5_IntCtrl_1_ADDR:	0x10f
BYTE			CSR_1SW5_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW5_IntEn_ADDR:	0xd
BYTE			CSR_1SW5_IntEn_ADDR;
#define CSR_1SW5_MASK 0x2
#pragma	ioport	CSR_1SW5_MUXBusCtrl_ADDR:	0x1db
BYTE			CSR_1SW5_MUXBusCtrl_ADDR;
// CSR_1SW5 Shadow defines
//   CSR_1SW5_DataShadow define
extern BYTE Port_3_Data_SHADE;
#define CSR_1SW5_DataShadow (*(unsigned char*)&Port_3_Data_SHADE)
// CSR_1SW3 address and mask defines
#pragma	ioport	CSR_1SW3_Data_ADDR:	0xc
BYTE			CSR_1SW3_Data_ADDR;
#pragma	ioport	CSR_1SW3_DriveMode_0_ADDR:	0x10c
BYTE			CSR_1SW3_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW3_DriveMode_1_ADDR:	0x10d
BYTE			CSR_1SW3_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW3_DriveMode_2_ADDR:	0xf
BYTE			CSR_1SW3_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW3_GlobalSelect_ADDR:	0xe
BYTE			CSR_1SW3_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW3_IntCtrl_0_ADDR:	0x10e
BYTE			CSR_1SW3_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW3_IntCtrl_1_ADDR:	0x10f
BYTE			CSR_1SW3_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW3_IntEn_ADDR:	0xd
BYTE			CSR_1SW3_IntEn_ADDR;
#define CSR_1SW3_MASK 0x4
#pragma	ioport	CSR_1SW3_MUXBusCtrl_ADDR:	0x1db
BYTE			CSR_1SW3_MUXBusCtrl_ADDR;
// CSR_1SW3 Shadow defines
//   CSR_1SW3_DataShadow define
extern BYTE Port_3_Data_SHADE;
#define CSR_1SW3_DataShadow (*(unsigned char*)&Port_3_Data_SHADE)
// CSR_1SW4 address and mask defines
#pragma	ioport	CSR_1SW4_Data_ADDR:	0xc
BYTE			CSR_1SW4_Data_ADDR;
#pragma	ioport	CSR_1SW4_DriveMode_0_ADDR:	0x10c
BYTE			CSR_1SW4_DriveMode_0_ADDR;
#pragma	ioport	CSR_1SW4_DriveMode_1_ADDR:	0x10d
BYTE			CSR_1SW4_DriveMode_1_ADDR;
#pragma	ioport	CSR_1SW4_DriveMode_2_ADDR:	0xf
BYTE			CSR_1SW4_DriveMode_2_ADDR;
#pragma	ioport	CSR_1SW4_GlobalSelect_ADDR:	0xe
BYTE			CSR_1SW4_GlobalSelect_ADDR;
#pragma	ioport	CSR_1SW4_IntCtrl_0_ADDR:	0x10e
BYTE			CSR_1SW4_IntCtrl_0_ADDR;
#pragma	ioport	CSR_1SW4_IntCtrl_1_ADDR:	0x10f
BYTE			CSR_1SW4_IntCtrl_1_ADDR;
#pragma	ioport	CSR_1SW4_IntEn_ADDR:	0xd
BYTE			CSR_1SW4_IntEn_ADDR;
#define CSR_1SW4_MASK 0x8
#pragma	ioport	CSR_1SW4_MUXBusCtrl_ADDR:	0x1db
BYTE			CSR_1SW4_MUXBusCtrl_ADDR;
// CSR_1SW4 Shadow defines
//   CSR_1SW4_DataShadow define
extern BYTE Port_3_Data_SHADE;
#define CSR_1SW4_DataShadow (*(unsigned char*)&Port_3_Data_SHADE)
