//-----------------------------------------------------------------------  
// C main line  
//------------------------------------------------------------------------  
#include <m8c.h>        // part specific constants and macros  
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules  

BYTE bCnt = 0;
extern CSR_1_bSwitchNum;
extern BYTE  EzI2Cs_bRAM_RWcntr;
extern BYTE  EzI2Cs_bState;
int iI2Cbuf[7];
void main()  
{  
BYTE i;
    CSR_1_Start();  
    
/* Enable the global and local interrupts */  
    M8C_EnableGInt;  
    M8C_EnableIntMask (INT_MSK0, INT_MSK0_SLEEP);   
    
    CSR_1_SetDacCurrent(0x29,0);   //Sets DAC current to low range value 30h  
    CSR_1_SetScanSpeed(6); // Sets the scan speed to 20
    
    
	// Set up RAM buffer  
	EzI2Cs_SetRamBuffer(14, 0, (BYTE *)iI2Cbuf);  
	EzI2Cs_Start();

    while(1)  
    {  
        CSR_1_StartScan(0,7,0); // Scan 7 switches starting from switch 0  
        while(!(CSR_1_GetScanStatus() & CSR_1_SCAN_SET_COMPLETE));
        CSR_1_bUpdateBaseline(0);
//if  ((EzI2Cs_bState&0x0F)==0)
if  (EzI2Cs_bRAM_RWcntr>13)
        for (i=0;i<7;i++)
        {
//     		M8C_DisableGInt; 
//if  (EzI2Cs_bRAM_RWcntr!=((i<<1)+1)) 
 					iI2Cbuf[i]=CSR_1_iaSwResult[i];
//			M8C_EnableGInt;
		}	
    } 
}  // End of main  

